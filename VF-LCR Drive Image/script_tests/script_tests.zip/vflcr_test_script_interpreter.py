#!/usr/bin/python
# Author:  Sean Kerr <skerr@vulcaonforms.com>
# Test parser for simple VF-LCR test scripts
# Developed/Tested on Python 2.7.15, Petalinux 2019.1
# Re-implementation of bash script 'test_script_interpreter_loop_2'
#
# Changelist:
#
# 2021-07-01 - 1.0 - Initial release (skerr)
# 2021-07-08 - 1.1 - Added timestamps to detailed log file names

'''
vflcr_test_script_interpreter.py

usage:  python vflcr_test_script_interpreter.py {test_script_file} {delay}
{num_loops}

Parameters:
    test_script_file: Test script in CSV format
    delay: delay (in seconds) between loops
    num_loops: number of times to repeat the test sequence 

'''

import os
import time
import sys

VERSION = "1.1"
SYSCMD_START_ANYBUS = "/usr/bin/anybus-zynq > /dev/null &"
SYSCMD_STOP_ANYBUS = "start-stop-daemon -K -x /usr/bin/anybus-zynq"

def parse_command_output(command_string, output_string):
    '''Interprets the output from a single read/write command, and returns
    register value as an integer

    Parameters:
    command_string (string):  raw read/write command string
    output_string (string):  output from execution of command string

    Returns:
    int:  Value written to or read from register

    '''

    return int(output_string.split(":")[-1].rstrip("\n"), base=16)

class TestResult(object):
    '''Structured object to hold the results of each read/write command

    Parameters:
    output_string (string): output from execution of command string
    command (string): command string sent to the register read/write EXE
    limits (tuple): tuple containing inclusive limits, or None for absence
                    of limits
    test_group (string): group that the test item is a member of

    '''

    TEST_PASSED_STRING = " <<PASS>>"
    TEST_FAILED_STRING = " <<FAIL>>"

    def __init__(self, output_string, command, limits, test_group):
        self.output_string = output_string.strip()
        self.command = command
        self.parsed_output = parse_command_output(command, output_string)
        lower_limit = limits[0]
        upper_limit = limits[1]
        self.lower_limit = lower_limit
        self.upper_limit = upper_limit
        self.test_group = test_group

        # self.result being True means the test passed
        if (self.lower_limit is None and self.upper_limit is None):
            self.result = None
        else:
            if self.lower_limit is not None:
                self.result = (self.parsed_output >= self.lower_limit)
            if self.upper_limit is not None:
                self.result = self.result and (self.parsed_output <= self.upper_limit)

    def __str__(self):
        return self.command + " --> " + self.output_string


    def get_output_string_with_result(self):
        ''' Returns output string with limits, PASS/FAIL status, and test 
        group appended, in comma separated format

        output,lower limit,upper limit,pass status,test group
        '''

        ret = self.output_string + ","
        
        if self.lower_limit is None:
            ret += "None,"
        else:
            ret += (hex(self.lower_limit) + ",")

        if self.upper_limit is None:
            ret += "None,"
        else:
            ret += (hex(self.upper_limit) + ",")

        if self.result is True:
            ret += (self.TEST_PASSED_STRING + ",")
        elif self.result is False:
            ret += (self.TEST_FAILED_STRING + ",")
        else:
            ret += ","

        if self.test_group is not None:
            ret += (self.test_group)

        return ret

    def get_output_string(self):
        ''' Returns just the output string '''

        return self.output_string

    def get_test_result(self):
        ''' Returns the test result as boolean, or None for no limits test'''

        return self.result

class TestSequence(object):
    '''
    Class to record and execute a sequence of VF-LCR commands
    There will be one of these for each "split" command in the command file
    Ultimately, this will be calling an executable to send reg read/write
    commands to the LCR system

    Each instance of TestSequence can only be run one time
    To re-run some commands, one would need to create a new TestSequence
    object

    Parameters:
    temp_file_name (string): File path to a temporary text file used to pass
        commands to the register interaction EXE.  Also used as a unique
        identifier string for the test sequence object.
    commandList (string): List of strings containing test descriptions from the
        test plan CSV file.  Each entry corresponds to one single register
        read/write interaction.

    '''

    EXE_READ_WRITE_REG = "./read-write7_NOT_TestReg"
    CMD_READ = "r"
    CMD_WRITE = "w"

    def __init__(self, temp_file_name, commandList):
        # Constructer attempts to read the command list and store all info
        # commandList is a List, one entry per read/write command
        self.commands = []
        self.limits = [] # each is a tuple, (lower, upper), or None
        self.test_groups = [] # string or None
        self.ignored_text = []
        self.temp_file_name = temp_file_name # name of the file created to call the EXE

        for i, list_item in enumerate(commandList):
            # Line format is:  command,lower,upper,testgroup,comment
            items = list_item.strip().split(",")

            self.commands.append(items[0])

            # Record limits if they are available
            try:
                if items[1]:
                    lower = int(items[1], base=16)
                else:
                    lower = None

                if items[2]:
                    upper = int(items[2], base=16)
                else:
                    upper = None

                limits = (lower, upper)

            except IndexError:
                # This keeps us compatible with older scripts
                limits = (None, None)

            except:
                raise

            self.limits.append(limits)

            # Record the test group if it is available
            try:
                if items[3]:
                    test_group = items[3]
                else:
                    test_group = None
            except IndexError:
                test_group = None

            except:
                raise

            self.test_groups.append(test_group)

            # Don't really care if this fails
            try:
                ignored_text = str(items[4:])
            except:
                ignored_text = ""

            self.ignored_text.append(ignored_text)

        self.num_commands = len(self.commands)

        assert self.num_commands == len(self.limits)
        assert self.num_commands == len(self.test_groups)
        assert self.num_commands == len(self.ignored_text)

        #print "Created " + self.get_temp_file_name()

        self.results = []
        self.raw_output = None
        self.raw_output_list = None
        self.commands_executed = False

    def __len__(self):
        return self.num_commands()

    def get_temp_file_name(self):
        ''' Returns the name of the temporary command file '''
        return self.temp_file_name

    def get_commands(self):
        ''' Returns the list of commands to be sent to the read/write EXE '''
        return self.commands

    def get_limits(self):
        ''' Returns a list of limit tuples '''
        return self.limits

    def get_test_groups(self):
        ''' Returns a list of the test groups '''
        return self.test_groups

    def get_ignored_text(self):
        ''' Returns the list of ignored text from the commandList input '''
        return self.ignored_text

    def has_been_executed(self):
        ''' Returns a boolean value to indicate if command have been
        executed

        '''
        return self.commands_executed

    def get_system_call(self):
        ''' Returns the command line string used to call the read/write
        executable

        '''

        # Returns the call to the EXE file that reads/writes VFLCR
        # registers
        return (self.EXE_READ_WRITE_REG + " " + self.get_temp_file_name() +
                " > ./" + self.get_temp_file_name() + "_output.txt")

    def execute(self):
        ''' Executes the stored commands and records the output.  Generates
        a list of TestResult objects to store the data.

        Currently missing any meaningful error checking

        '''
        if self.commands_executed is False:
            with open(self.temp_file_name, 'w') as outfile:
                for command in self.get_commands():
                    outfile.write(command + os.linesep)

            # Not really sure how to capture STDOUT with os.system
            # As a workaround, we are writing to a temporary file then
            # deleting that file
            os.system(self.get_system_call())
            with open(self.get_temp_file_name() + "_output.txt", 'r') as infile:
                self.raw_output_list = infile.readlines()

            # This should clean up all temp files created by this executable
            # calling process
            os.system("rm " + self.get_temp_file_name() + "*")

            # TODO: decide how to handle a case where the EXE output is and
            # unexpected length.  Or more generally, decide how to handle
            # errors of any kind in the EXE call
            assert self.num_commands == len(self.raw_output_list)

            for i in range(self.num_commands):
                self.results.append(TestResult(self.raw_output_list[i],
                                               self.get_commands()[i],
                                               self.get_limits()[i],
                                               self.get_test_groups()[i]))

            self.commands_executed = True

            #debug
            #for result in self.results:
                #print result

        else:
            print "Skipping commands in " + self.get_temp_file_name()
            print "This test sequence has already executed!"

    def get_results(self):
        ''' Returns a list of test results if commands have been executed.
        Otherwise, returns None.

        '''
        if self.commands_executed:
            ret = self.results
        else:
            ret = None
            print self.get_temp_file_name() + " has not been executed!"

        return ret

    def clear_results(self):
        ''' Clears test results, so that commands can be executed again and new
        results stored.

        '''

        self.results = []
        self.raw_output = None
        self.raw_output_list = None
        self.commands_executed = False

class TestRecord(object):
    ''' Parses a test definition file

    Generates one TestSequence object per required call to the read/write
    executable.  Parses completed TestSequence objects to collect any
    high-level data regarding the overall pass/fail status

    Parameters:
    command_file_name (string): file path to CSV file containing the test
        definition

    '''

    def __init__(self, command_file_name):
        self.command_file_name = command_file_name

        try:
            with open(self.command_file_name, 'r') as infile:
                self.command_file_lines = infile.readlines()
        except:
            print "Error reading command file!"
            # maybe do other stuff here
            raise

        self.test_group_list = []
        self.test_group_pass_status = {}
        self.test_group_results = {}
        self.test_group_parsed_sequences = []
        self.all_tests_passed = True

        self.test_sequences = []
        self.post_sequence_delays = []
        self.num_test_sequences = 0

        line_buffer = []

        for i in range(len(self.command_file_lines)):
            line = self.command_file_lines[i].strip()
            #debug
            #print line

            if line.strip().split(" ")[0] == "split":
                delay_seconds = float(line.strip().split(" ")[1].rstrip("s"))

                self.add_test_sequence(line_buffer, delay_seconds)
                line_buffer = []

            else:
                line_buffer.append(line)


    def add_test_sequence(self, command_file_lines, delay_seconds):
        '''Creates a new TestSequence object and adds it to the internal test
        sequence list

        Parameters:
        command_file_lines (list): list of test item strings which make up the
            test sequence.  One list item corresponds to one single read/write
            command
        delay_seconds (float): number of seconds to delay after this sequence
            has been executed

        '''

        sequence_name = self.command_file_name + "__" + str(self.num_test_sequences)
        self.test_sequences.append(TestSequence(sequence_name, command_file_lines))
        self.post_sequence_delays.append(delay_seconds)
        self.num_test_sequences += 1

    def run_tests(self):
        '''Executes all test sequences in the sequence list, then parses out
        pass/fail data for all test groups

        '''
        for i in range(self.num_test_sequences):
            self.test_sequences[i].execute()
            self.parse_test_data(self.test_sequences[i])
            time.sleep(self.post_sequence_delays[i])

    def parse_test_data(self, test_sequence):
        '''Reads through the results of a test sequence, then pulls out any
        pass/fail results and stores the data internally.

        '''

        if not test_sequence.has_been_executed():
            print "Cannot parse group data for" + test_sequence.get_temp_file_name()
            print "The commands have not been executed!"
        else:
            if test_sequence.get_temp_file_name() in self.test_group_parsed_sequences:
                print "Cannot parse group data for" + test_sequence.get_temp_file_name()
                print "It has already been parsed!"
            else:
                for test_result in test_sequence.get_results():
                    if test_result.get_test_result() is not None:
                        self.all_tests_passed &= test_result.get_test_result()

                    if test_result.test_group is not None:
                        if test_result.test_group not in self.test_group_list:
                            self.test_group_list.append(test_result.test_group)
                            self.test_group_pass_status[test_result.test_group] = True
                            self.test_group_results[test_result.test_group] = []

                        self.test_group_pass_status[test_result.test_group] &= \
                            test_result.get_test_result()

                        self.test_group_results[test_result.test_group].append(
                            test_result)

                    self.test_group_parsed_sequences.append(
                        test_sequence.get_temp_file_name())

    def get_test_item_results(self):
        ''' Returns a string containing results for each individual test item.
        String contains line breaks, with line line per test item output.

        '''

        ret = "Test Output for " + self.command_file_name + os.linesep

        for sequence in self.test_sequences:
            for result in sequence.get_results():
                ret += (result.get_output_string_with_result()
                        + os.linesep)

        return ret

    def get_test_group_results(self):
        ''' Returns pass/fail status of each test group '''

        ret = "Test Group Results for " + self.command_file_name + os.linesep

        for group in self.test_group_list:
            ret += (group + ":  " +
                    ("PASS" if self.test_group_pass_status[group] else "FAIL")
                    + os.linesep)

        return ret


    def get_test_results(self):
        ''' Returns overall pass/fail status as a string '''

        ret = "VFLCR Test Interpreter Version:  " + VERSION + os.linesep
        ret += ("Overall output for " + self.command_file_name + " = " +
               ("PASS" if self.all_tests_passed else "FAIL"))
        ret += os.linesep

        return ret


    def clear_results(self):
        '''Clears the results of all TestSequence objects in the test sequence
        list, as well as all test group data stored internally

        '''
        for seq in self.test_sequences:
            seq.clear_results()

        self.test_group_list = []
        self.test_group_pass_status = {}
        self.test_group_results = {}
        self.test_group_parsed_sequences = []

# Test script starts here
os.system(SYSCMD_STOP_ANYBUS)

FILENAME = sys.argv[1]
DELAY_SECONDS = float(sys.argv[2])
NUM_LOOPS = int(sys.argv[3])

test_record = TestRecord(FILENAME)
for loopcount in range(NUM_LOOPS):

    test_record.clear_results()
    test_record.run_tests()

    logpath = "./script_outputs/"

    if not os.path.exists(logpath):
        os.mkdir(logpath)

    # date/time string keeps each file name unique
    logpath += (time.strftime("%Y%m%d%H%M%S") + "__")
    logpath += (FILENAME.rstrip('.csv') + "__results.csv")
    with open(logpath, 'w') as outfile:
        outfile.write(test_record.get_test_item_results())

    print test_record.get_test_group_results()
    print test_record.get_test_results()

    time.sleep(DELAY_SECONDS)

os.system(SYSCMD_START_ANYBUS)
